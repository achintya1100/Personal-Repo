//24 Points
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    // first, read the number
    signed short int input;
    fscanf(fp, "%hd", &input); // note how the 'h' modifier shortens the %d to half size


    //0b1010_1010_1010_1010 - input 
    //                  0b1 - iter 15(input >> 15)
    //                  0b10 - iter 14(input >> 14)
    //                  0b101 - iter 13(input >> 13)
    //

    //Char Val

    

    for ( int digit=15; 0<=digit; digit = digit - 4) 
    {
        unsigned int char_val = 0b1111 & input >> (digit - 3); // shift and mask
        printf("%x",char_val);
    }
    printf("\n");

    /*
    int power(int base, int exponent)
    {
        if(exponent != 0)
        {
            return base * power(base, exponent - 1);
        }
        else
            return 1;
    }

    int val;
    // print bits; you will see this kind of for loop often in this assignment
    for ( int digit=15; 0<=digit; digit-- ) {
        //char hex;
        int counter = 3;
        if(digit % 4 != 0)
        {
            bool char_val = 0b1 & input>>digit; // shift and mask
            //printf("%d",char_val);
            if(char_val == 1)
            {
                val += power(2, counter);
                printf("counter: %d", counter);
            }
            counter--;
        }
        if(digit % 4 == 0)
        {
            while(val != 0)
            {
                int remainder = val % 16;
                if(remainder < 10)
                {
                    remainder += 48;
                    //printf("The character value of remainder = %c\n", remainder);
                    continue;
                }
                else
                {
                    remainder += 55;
                    //printf("The character value of remainder = %c\n", remainder);
                    continue;
                }
            }
        }
    }
    printf("\n");

    */

    // useful hints for printing uppercase hexadecimal
    //printf("The character value of '0' = %d\n",'0');
    //printf("The character value of 'A' = %d\n",'A');

    return EXIT_SUCCESS;

}

