//24 Points
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    // SETUP

    // first, read the minuend (number to be subtracted from)
    char buff;
    bool minuend[8]; // suggested that you store bits as array of bools; minuend[0] is the LSB
    for (int i = 0; i <= 8; i++) 
    { // read MSB first as that is what comes first in the file
        fscanf(fp, "%c", &buff);
        if(buff == '1')
        {
            minuend[i] = 1;
        }
        if(buff == '0')
        {
            minuend[i] = 0;
        }
    }

    // notice that you are reading two different lines; caution with reading
    /* ... */

    // second, read the subtrahend (number to subtract)
    bool subtrahend[8]; // suggested that you store bits as array of bools; subtrahend[0] is the LSB
    for (int i = 0; i <= 8; i++) 
    { // read MSB first as that is what comes first in the file
        fscanf(fp, "%c", &buff);
        if(buff == '1')
        {
            subtrahend[i] = 1;
        }
        if(buff == '0')
        {
            subtrahend[i] = 0;
        }
    }

    /*
    printf("%s", "Printing Minuend and Subtrahend before Negation");
    printf("\n");
    for(int i=7; 0<=i; i--)
    {
        printf("%d",minuend[i]);
    }
    printf("\n");
    for(int i=7; 0<=i; i--)
    {
        printf("%d",subtrahend[i]);
    }
    printf("\n");
    */

    // WE WILL DO SUBTRACTION BY NEGATING THE SUBTRAHEND AND ADD THAT TO THE MINUEND
    //printf("%s", "Printing Subtrahend After Negation");
    // Negate the subtrahend
    // flip all bits
    for(int i = 0; i < 8; i++)
    {
        subtrahend[i] = !subtrahend[i];
    }

    /*
    printf("\n");
    for(int i=7; 0<=i; i--)
    {
        printf("%d",subtrahend[i]);
    }
    */

    //11111111
    //00000001
    //+_______
    //00000000
    //carry 1

    // add one
    bool carry = true; // to implement the 'add one' logic, we do binary addition logic with carry set to true at the beginning
    for (int i = 7; 0 <= i; i--) 
    { // iterate from LSB to MSB
        bool temp = (carry + subtrahend[i]) % 2;
        carry = (carry + subtrahend[i]) / 2;
        subtrahend[i] = temp;
    }

    // Add the minuend and the negated subtrahend
    bool difference[8];
    bool carryForward = false;
    /*
    for(int i = 0; i < 8; i++)
    {
        if(minuend[i] == 1 && subtrahend[i] == 1)
        {
            difference[i] = 0;
            continue;
        }
        else
        if(minuend[i] == 0 && subtrahend[i] == 0)
        {
            difference[i] = 0;
            continue;
        }
        else
        if(minuend[i] == 1 && subtrahend[i] == 0)
        {
            difference[i] = 1;
            continue;
        }
        else
        if(minuend[i] == 0 && subtrahend[i] == 1)   //If no 0 - 1 after current 
        {
            difference[i] = 1;
            while(temp + 1 < 8)
            {
                temp = temp + 1;
                if(minuend[temp] == 1)
                {
                    minuend[temp] = 0;
                    carryForward = false;
                }
            }
            
            int temp = i;
            carryForward = true;
            
            continue;
        }
    }
    */
    for(int i = 7; 0 <= i; i--)
    {
        difference[i] = (carryForward + subtrahend[i] + minuend[i]) % 2;
        carryForward = (carryForward + subtrahend[i] + minuend[i]) / 2;
    }
    // printf("\n");
    // printf("%s", "Printing Difference");
    // printf("\n");
    // print the difference bit string
    for(int i = 0; i < 8; i++)
    {
        printf("%d",difference[i]);
    }
    
    
    return EXIT_SUCCESS;
}