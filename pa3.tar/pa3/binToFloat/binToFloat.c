#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define EXP_SZ 8
#define FRAC_SZ 23

int power(int base, int exponent)
    {
        if(exponent != 0)
        {
            return base * power(base, exponent - 1);
        }
        else
            return 1;
    }

int main(int argc, char *argv[]) {

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    // SETUP

    // first, read the binary number representation of float point number
    char buff;
    unsigned int binary = 0;
    for (int i=EXP_SZ+FRAC_SZ; 0<=i; i--) { // read MSB first as that is what comes first in the file
        fscanf(fp, "%c", &buff);
        binary += buff=='1' ? 1<<i : 0; //
    }

    //float number = (float) binary;
    //float number = *(float *)&binary; // you are not allowed to do this.

    //Sign
    //Represented by a single bit. 1 indicates a negative number, 0  indicates positive number.
    bool sign = (0b1 & binary) << 1;
    //printf("%d", sign);

    // Exponent E - Normalized vs Denormalized
    //Normalized -> E = exp - bias
    //Denormalized -> E = -126
    binary = binary << 1;
    binary = binary >> 24;
    int expMask = 0b00000000000000000000000011111111 & binary;
    int bias = 127;
    int e;
    if(expMask != 0)
    {
        e = expMask - bias;   //Biased exponent when exp not equal to 0
    }
    else
    {
        e = 1 - bias;
    }
    /*
    int value;
    int counter = 0;
    //int e;
    do
    {
        (0b1 & binary) >> 1;
        continue;
    }
    while(counter < 8)
    {
        value += (0b1 & binary) >> 1;
        counter++;
    }
    printf("%d", value);
    */
    // Mantissa M

    double m;
    int mantisMask = (0b00000000011111111111111111111111) & binary;
    int currentBit;
    if(e != -126)   //Normalized Number
    {
        for(int i = 1; i < 24; i++)
        {
            currentBit = (0b1 & mantisMask) << i;
            if(currentBit == 1)
            {
                //printf("%d\n", currentBit);
                m += 1/(power(2, i));
            }
        }
        m = m + 1;
    }
    else
    if(e == -126)    //Denormalized Number
    {
        for(int i = 1; i < 24; i++)
        {
            currentBit = (0b1 & mantisMask) << i;
            if(currentBit == 1)
            {
                //printf("%d ", currentBit);
                m += 1/(power(2, i));
            }
            else
            if(currentBit == 0)
            {
                m+=0;
            }
        }
    }

    /*
    double m;
    int mantisMask = 0b00000000011111111111111111111111 & binary;
    for (int i = 0; i < 23; i++) 
    {
        int temp = 0b1 & mantisMask >> 1;
        if(temp == 1)
        {
            m += 1/power(2, i);
        }
        else
        if(temp == 0)
        {
            continue;
        }
    }
    */

    // https://www.tutorialspoint.com/c_standard_library/c_function_ldexp.htm
    double number = ldexp ( m, e );
    number = sign ? -number : number;
    printf("%e\n", number);

    return EXIT_SUCCESS;

}
