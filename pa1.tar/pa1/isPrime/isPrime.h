#include <stdlib.h>
#include <stdio.h>
#include <math.h>

//Function declarations
bool is_prime(int n);
bool is_not_prime(int n);
