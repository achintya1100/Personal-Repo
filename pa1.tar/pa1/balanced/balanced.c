//22 points
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

// Struct to hold the expected close brace character and a pointer to the next element.
struct element {
    char close;
    struct element* next;
};

//Functions Declarations
//bool checkPeek(struct element, char check);

int main(int argc, char* argv[])
{
	int parenthesesCounter = 0;
	int bracketsCounter = 0;
	int bracesCounter = 0;
	int angleBrackets = 0;

    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    bool balanced = true;
    char buff;
    while ( fscanf(fp, "%c", &buff)==1 ) 
    {
		if(buff == '(')
		{
			parenthesesCounter = parenthesesCounter + 1;
		}
		if(buff == '{')
		{
			bracketsCounter = bracketsCounter + 1;
		}
		if(buff == '[')
		{
			bracesCounter = bracesCounter + 1;
		}
		if(buff == '<')
		{
			angleBrackets = angleBrackets + 1;
		}
		if(buff == ')')
		{
			parenthesesCounter = parenthesesCounter - 1;
		}
		if(buff == '}')
		{
			bracketsCounter = bracketsCounter - 1;
		}
		if(buff == ']')
		{
			bracesCounter = bracesCounter - 1;
		}
		if(buff == '>')
		{
			angleBrackets = angleBrackets - 1;
		}
    }

	if(parenthesesCounter == 0 && bracketsCounter == 0 && bracesCounter == 0 && angleBrackets == 0)
	{
		balanced = true;
	}
	else
	{
		balanced = false;
	}

    printf ( balanced ? "yes" : "no" );
    fclose(fp);
    return 0;
}

/**
int pop (node ** head){
	node * temp = NULL;

	if(*head==NULL){
		return -1;
	}

	else{
		temp = *head;
		*head = (**head).next; //(*head)->next;
		int res = temp->num;
		free(temp);
		return res;
	}
}

void push (node ** head, int val){

	node * temp = malloc(1*sizeof(node));
	temp->num = val;
	temp->next = *head;
	*head = temp;
	return;
}

void freestack(node ** first_node){
	node * ptr = *first_node;
	while(ptr!=NULL){
		freestack(&ptr->next);
		free(ptr);
	}
}


//Insert a matching closing brace into the stack to keep track of braces.
void push(struct* element, char value)
{
	if(value == '(')
	{
		element.
	}
	else
	if(value == '[')
	{

	}
	else
	if(value == '{')
	{

	}
	else
	{
		//All other values ignored.
	}
}

//Return the top brace in the stack.
char pop(struct element)
{
	char returnChar;
	if(close->next != '(' && close->next != '{' && close->next != '[')
	{
		break;	//Break out of method if no type of brace is detected in stack.
	}
	else
	{
		returnChar = element->close;	//Store the value in a temp variable that will be used to return the popped value.
		element = element->next;	//Reassign the current node to the next value in stack.
	}
	return returnChar;
}

bool checkPeek(struct element, char value)
{
	while(value != pop(element))
	{
		if(pop(element)
	}
}

*/