//15 points

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>

//Function declerations
bool is_prime(int n);
int closestPrime(int n);

int num1;	// (39/2) = 19
int num2; 	// (19/2) = 9 (+2)
int num3;	// (11/2) = 5 (+2) (+2)
int closestPrimeNum;


int main(int argc, char* argv[]) 
{
  int number = atoi(argv[1]);
  int nCopy = number;
  num1 = closestPrime(number / 2);
  number = number - num1;
  num2 = closestPrime(number / 2);
  number = number - num2;
  num3 = closestPrime(number);
  printf("%d = %d + %d + %d\n", nCopy, num1, num2, num3);
  //printf("%d", closestPrime(number));
}

/**
closestPrimeNum = closestPrime(n / 2)
n - closestPrimeNum
closestPrimeNum / 2;
closestPrime


n = 23
23 - 2 = 21
21 - 2 = 19
19 - 2 = 17
17 - 2 = 15
15 - 2 = 13
13 - 2 = 11

23 = 17 + 3 + 3

if(remainder = 6)
{
	return 3 and 3
}

if(remainder 4)
{
	return 2 and 2
}

53 / 2 = 26
closestPrime(26) = 23
53-23 = 20
20/2 = 10
closestPrime(10) = 11
23 + 11 = 34
53-34 = 19
closestPrime(19) = 19
19+11+23=53

69/2=34
closestPrime(34) = 31
69-31=38
38/2 =19
closestPrime(19) = 19





isPrime(7-2) = T


*/


//Check to make sure that num1, num2, or num3 are prime numbers.
bool is_prime(int n)
{
	int x = n - 1;
	while(x > 1)
	{
		if(n % x == 0)
    	{
			return false;
		}
		x--;
	}
	return true;
}

//Iteratively calculate using Goldbach's Weak Conjecture.
int closestPrime(int n)
{
	if(is_prime(n))
	{
		return n;
	}	
	else
	{
		while(!is_prime(n))
		{
			n--;
		}
	}
	return n;
}