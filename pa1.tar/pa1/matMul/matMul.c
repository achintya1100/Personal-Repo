#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

//Function Declaration
void multiply(int** mat1, int** mat2, int rows1, int rows2, int cols1, int cols2);

int main(int argc, char* argv[])
{
    FILE* matrix_a_fp = fopen(argv[1], "r");
    if (!matrix_a_fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    char buff[256];
    //Matrix A
    fscanf(matrix_a_fp, "%s", buff);
    char length_l = atoi(buff);
    int** matrix_a = malloc( length_l * sizeof(int*) );

    fscanf(matrix_a_fp, "%s", buff);
    char length_m = atoi(buff);
    for ( unsigned char i=0; i<length_l; i++ ) {
        matrix_a[i] = malloc( length_m * sizeof(int) );
    }

    int temp2 = 0;
        for(int i = 0; i < length_l; i++)
        {
            for(int j = 0; j < length_m; j++)
            {
                fscanf(matrix_a_fp, "%d", &temp2);
                matrix_a[i][j] = temp2;
            }
        }

    fclose(matrix_a_fp);

    //Matrix B
    FILE* matrix_b_fp = fopen(argv[2], "r");
        if (!matrix_b_fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    fscanf(matrix_b_fp, "%s", buff);
    char length_n = atoi(buff);
    int** matrix_b = malloc( length_n * sizeof(int*) );

    fscanf(matrix_b_fp, "%s", buff);
    char length_o = atoi(buff);
    for ( unsigned char i=0; i<length_n; i++ ) {
        matrix_b[i] = malloc( length_o * sizeof(int) );
    }

     int temp3 = 0;
        for(int i = 0; i < length_n; i++)
        {
            for(int j = 0; j < length_o; j++)
            {
                fscanf(matrix_b_fp, "%d", &temp3);
                matrix_b[i][j] = temp3;
            }
        }


    fclose(matrix_b_fp);

    // for(int i = 0; i < length_l; i++)
    // {
    //     for(int j = 0; j < length_m; j++)
    //     {
    //         printf("%d", matrix_a[i][j]);
    //     }
    // }

    // for(int i = 0; i < length_n; i++)
    // {
    //     for(int j = 0; j < length_o; j++)
    //     {
    //         printf("%d", matrix_b[i][j]);
    //     }
    // }

    multiply(matrix_a, matrix_b, length_l, length_m, length_n, length_o);

    //Removing Matrix A from memory.
    for ( unsigned char i=0; i<length_l; i++ ) {
        free( matrix_a[i] );
    }
    free( matrix_a );

    //Removing Matrix B from memory
    for ( unsigned char i=0; i<length_n; i++ ) {
        free( matrix_b[i] );
    }
    free( matrix_b );

    return 0;
}

//Matrix Multiplication. Prints resulting array and frees memory too.
void multiply(int** matrix_a, int** matrix_b, int rows1, int rows2, int cols1, int cols2)
{
    int** resultArray = malloc((rows1)*sizeof(int*));
    for(int i = 0; i < rows1; i++)
    {
        resultArray[i] = malloc(cols2*sizeof(int));
    }

    //Populate the array.
    for(int i = 0; i < rows1; i++)
    {
        for(int j = 0; j < cols2; j++)
        {
            resultArray[i][j] = 0;
        }
    }

    //Matrix Multiplication
    int temp = 0;
    for (int i = 0; i < rows1; i++) 
    {
        for (int j = 0; j < cols2; j++) 
        {
            for (int k = 0; k < cols1; k++)
            {
                temp += matrix_a[i][k] * matrix_b[k][j];
            }
            resultArray[i][j] = temp;
            temp = 0;
        }
    }

    //Printing resulting array.
    for(int i = 0; i < rows1; i++)
    {
        for(int j = 0; j < cols2; j++)
        {
            printf("%d ", resultArray[i][j]);
        }
    }
    printf("\n");
    

    for(int i = 0; i < rows1; i++)
    {
        free(resultArray[i]);
    }

    free(resultArray);
}