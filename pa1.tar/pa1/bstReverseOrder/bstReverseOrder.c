//22 Points

#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

/**
* In BST, smaller leaves are on left, larger values are on right.
* BFS(Level Order Traversal) - Queue(FIFO)
* DFS(In Order, Reverse Order Traversal) - Stack(LIFO)
*/

/**
* Structs are data structures in C.
* Need to store reference to left and right children of current parent node.
* Access structs with BSTNode* root;
* (*root).val = val; or root->val = val;
*/
//typedef struct bstNode bstNode;
struct bstNode {
    int val;
    struct bstNode* l_child;
    struct bstNode* r_child;
};

struct bstNode* insert(struct bstNode* root, int val)
{
    //If bstNode doesn't exist yet.
    if(root == NULL)
    {
        root = malloc(sizeof(struct bstNode));
        root->val = val;
        root->l_child = NULL;
        root->r_child = NULL;
        
    }
    //If the bstNode already exists, then insert key in the correct subtree.
    if(val < root->val)
    {
        root->l_child = insert(root->l_child, val);
    }
    else
    if(val == root->val)
    {
        //duplicates are ignored.
    }
    else
    {
        root->r_child = insert(root->r_child, val);
    }
    return root;
}

//Recursively delete tree from the bottom up.
void delete_bst(struct bstNode* root)
{
    if(root->r_child)
    {
        delete_bst(root->r_child);
    }
    if(root->l_child)
    {
        delete_bst(root->l_child);
    }
    free(root);
}

//Recursively traverse through the tree.
void traversal(struct bstNode* root)
{
    if(root == NULL)
    {
        return;
    }
    //Reverse-order traversal - Right subtree, root, left subtree.
    traversal(root->r_child);
    printf("%d ", root->val);
    traversal(root->l_child);
}

/**
Class Notes on In-Order Traversal Using a Queue
--------------------

typedef struct QueueNode QueueNode;
struct QueueNode
{
    bstNode* data;
    QueueNode* next;
};

typedef struct Queue
{
    QueueNode* front;
    QueueNode* back;
}   Queue;

//Append a new QueueNode to the back of the Queue
Queue enqueue(Queue queue, bstNode* data)
{
    QueueNode* queueNode = malloc(sizeof(QueueNode));
    queueNode->data = data;
    queueNode->next = NULL; //At back of the queue, there is no next node;

    if(queue.back == NULL)
    {
        queue.front queueNode;
        queue.back = queueNode;
    }
    else
    {
        queue.back->next = queueNode; //shorthand for (queue.back).next = queueNode;
        queue.back = queueNode;
    }
    return queue;

    bstNode* dequeue(Queue* queue)
    {
        if(queue->front == NULL)
        {
            return NULL;
        }
        else
        {
            //The QueueNode at front of the queue to be removed.
            QueueNode* temp = queue->front;
            if(queue->back == temp) //If the queue will become empty.
            {
                queue->back == NULL;
            }
        bstNode* bstNod
        }
    }
}
*/

int main(int argc, char* argv[])
{
    FILE* fp = fopen(argv[1], "r");
    if (!fp) {
        perror("fopen failed");
        return EXIT_FAILURE;
    }

    struct bstNode* root = NULL;

    unsigned int temp;
    while ( fscanf(fp, "%d", &temp)!=EOF ) 
    {
        root = insert(root, temp);
    }
    traversal(root);
    fclose(fp);
    return 0;
}