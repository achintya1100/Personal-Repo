//22 points

#include <stdlib.h>
#include <stdio.h>

int main(int argc, char* argv[]) 
{
  FILE* fp = fopen(argv[1], "r");
  if (!fp) 
  {
    perror("fopen failed");
    return EXIT_FAILURE;
  }
  //Store numElements, n maximum values to be printed, and values to be sorted.
  int numElements;
  int numMaximum;
  unsigned int num;
  fscanf(fp, "%d", &numElements);
  int array[numElements];
  fscanf(fp, "%d", &numMaximum);
  for(int i = 0; i < numElements; i++)
  {
    fscanf(fp, "%d", &num);
    array[i] = num;
  }

  //Sort array in descending order.
  int temp;
  for(int i = 0; i < numElements; i++)
  {
    for(int j = i + 1; j < numElements; j++)
    {
      if(array[i] < array[j])
      {
        temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }
    }
  }

  //Printing n maximum elements
  for(int i = 0; i < numMaximum; i++)
  {
    printf("%d ", array[i]);
  }

  fclose(fp);

}
