#include "../graphutils.h"

// A program to find a cycle in a directed graph

// You may use DFS or BFS as needed
bool isTreeDFS (
    size_t graphNodeCount,
    AdjacencyListNode* adjacencyList,
    bool* visited,
    graphNode_t parent,
    graphNode_t current
) {
    // First see if current node has already been visited, indicating a cycle found
    if(visited[current] == 1)
    {
        return false;
    }
    // Current node was not already visited, so now mark it as visited
    if(visited[current] == 0)
    {
        visited[current] = 1;
    }

    // Now iterate through each of the neighboring graph nodes
    AdjacencyListNode* neighbor = adjacencyList[current].next;
    graphNode_t visitedArray[graphNodeCount];
    int counter = 0;
    while (neighbor) {
        if (neighbor->graphNode!=parent) 
        {
            // If the neighbor nodes is not the parent node (the node from which we arrived at current), call DFS
            isTreeDFS(graphNodeCount, adjacencyList, visited, current, neighbor-> graphNode);
            visitedArray[counter] = current;
            counter++;
        }

        neighbor = neighbor->next;
    }

    for(int i = 0; i < graphNodeCount; i++)
    {
        graphNode_t temp = visitedArray[i];
        for(int j = 0; j < graphNodeCount; j++)
        {
            if(temp == visitedArray[j])
            {
                return false;
            }
        }
    }

    // All DFS searches from current node found no cycles, so graph is a tree from this node
    return true;
}

int main ( int argc, char* argv[] ) {

    // READ INPUT FILE TO CREATE GRAPH ADJACENCY LIST
    AdjacencyListNode* adjacencyList;
    size_t graphNodeCount;
    graphNodeCount = adjMatrixToList(argv[1], &adjacencyList);

    //graphNode* arrayVals = malloc(graphNode * sizeof(graphNode_t));
    bool visited[graphNodeCount];
    for(int i = 0; i < graphNodeCount; i++)
    {
        visited[i] = false;
    }
    //bool* visited = calloc ( graphNodeCount, sizeof(bool) );
    bool isCyclic = false;

    for (unsigned source=0; source<graphNodeCount; source++) 
    {
        if(isTreeDFS(graphNodeCount, adjacencyList, visited, 0, 0) == false)
        {
            isCyclic = true;
            //printf("%s\n", "t");
            AdjacencyListNode* temp = &adjacencyList[source];
            while(adjacencyList[source].next != NULL)
            {
                printf("%ld ", temp->graphNode);
                //counter++;
                temp = temp->next;
                if(temp->next == NULL)
                {
                    break;
                }
            }
            //printf("%d", counter);
            break;
        }
        else
        {
            for(int i = 0; i < graphNodeCount; i++)
            {
                visited[i] = false;
            }
            if(isTreeDFS(graphNodeCount - source, adjacencyList, visited, 0, 0) == true)
            {
                isCyclic = false;
                //printf("%s", "f");
                break;
            }
        }
    }

    if (!isCyclic) { printf("DAG\n"); }

    freeAdjList ( graphNodeCount, adjacencyList );
    //free(visited);
    return EXIT_SUCCESS;
} 
